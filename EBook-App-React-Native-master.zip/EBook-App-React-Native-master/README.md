# ℹ️ EBook-App-React-Native

 EBook is very simple Application.It Contains Information abouts Books

 This Application only tested in Android Device's Only.In Future it will also test in Ios Device's
 
 ---

# 👁️‍🗨️ Preview of Application in Android Emulator

This App is tested and Runed in Android Emulator Only.

<div align='center'>

https://user-images.githubusercontent.com/66934377/158441640-304514d3-0ed7-47ee-b6a9-91e87359045c.mp4
     
</div>

---

# 🗂️ FrameWork

The Below Framework's is used in this Project. To run this Projec. This Framework's has been installed in system with same Vesion or Latest Version.

| FrameWork  | Version's |
| ------------- | ------------- |
| React Native  | 0.67  |
| Node.js  | 16.14.0  |

---

 # 👨‍💻 Command for Execute Project

```bash
  npm run android
```
---

# ⬇️ Code Downloading Process

* You Can Download the code in **2 Methods**
* Choose Any One Methode has your whish

---

# Ⓜ️ Methode 1

* **This Methode is Very Easy**

* Now Click on __Code Option__

![Screenshot (158)](https://user-images.githubusercontent.com/66934377/164152919-f2854829-535d-4227-9c2f-031f8051f6ac.png)

* Now A Screen will Popup. Now Click **Download Zip** Option . Now the file has been started downloading 

![Screenshot (159)](https://user-images.githubusercontent.com/66934377/164153128-b64e85a2-e40c-4457-9835-a749ac79acd6.png)

---

# Ⓜ️ Methode 2

* **This Methode is tittle bit Hard**

* Now Open **cmd** in windows, **bash Terminal** in mac. Now Hit the Below Command's

```bash
git clone https://github.com/Manju1392k/EBook-App-React-Native.git
```

* The project cloned after this process

---

# 📦 Extra Packages for Project

* This packages are important for project without this package's the project can't run.

---
## For Node Modules
```bash
npm install node
```
